/**
 * This package contains classes used to specify positioning of watermarks and
 * other objects in Thumbnailator.
 */
package net.coobird.thumbnailator.geometry;
