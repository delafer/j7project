/**
 * This package provides classes which perform filtering operations on images,
 * such as adding watermark, text captions, and color tints.
 */
package net.coobird.thumbnailator.filters;
