/**
 * This package provides classes which perform image input and output
 * operations in conjunction with the
 * {@link net.coobird.thumbnailator.tasks.SourceSinkThumbnailTask} class.
 */
package net.coobird.thumbnailator.tasks.io;
