/**
 * This package contains classes used to generate file names when saving
 * thumbnail images to files.
 */
package net.coobird.thumbnailator.name;
