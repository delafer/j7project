/**
 * This package contains classes which provide the core functionalities of
 * Thumbnailator.
 */
package net.coobird.thumbnailator;
